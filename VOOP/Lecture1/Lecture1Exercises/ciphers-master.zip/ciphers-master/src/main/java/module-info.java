module vop {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;

    opens vop;
}